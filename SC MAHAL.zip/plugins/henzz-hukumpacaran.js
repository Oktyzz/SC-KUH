let fs = require('fs')
let handler = async (m, { conn }) => {
let teks = 'hukum pacaran'
let anu = `*Hukum* orang pacaran dalam Islam bisa kamu pahami dari Al-Quran dan hadis. Dalam Islam, seorang muslim tidak boleh mempunyai kekasih kecuali dengan ikatan pernikahan. Kamu bisa merujuk pada beberapa surah Al-Quran dan hadis berikut tentang hukum orang pacaran dalam Islam:

Hukum orang pacaran dalam Islam yang pertama dapat merujuk pada Surah Al-Isra ayat 32, yang artinya:

“Dan janganlah kamu mendekati zina; sesungguhnya zina itu adalah suatu perbuatan yang keji dan suatu jalan yang buruk.” (QS. al-Isra’ (17): 32)

Selain itu, dalam sebuah hadus muttafaq alaihi, Rasulullah SAW pernah membahas tentang tindakan yang mendekatkan seorang muslim terhadap zina. Hal ini juga berkaitan dengan hukum orang pacaran dalam Islam. Bunyi hadis tersebut yaitu sebagai berikut:
اَ يَخْلُوَنَّ رَجُلٌ بِامْرَأَةٍ إِلاَّوَمَعَهاَذُو مَحْرَمٍ

“Tidak boleh di antara laki-laki dan perempuan berduaan, kecuali disertai oleh muhrim nya (orang lain yang semuhrim), dan seorang wanita dilarang bepergian kecuali ditemani oleh mahram nya.” (HR. Muslim).

Beliau pun bersabda:

أَلاَ لاَ يَخْلُوَنَّ رَجُلٌ باِمْرَأَةٍ إِلاَّكاَنَ ثَالِثَهُمَا الشَّيْطَانُ
“Ingatlah, bahwa tidaklah seorang laki-laki itu berkhalwat dengan seorang wanita kecuali yang ketiganya adalah setan” (HR. Ahmad, At-Tirmidzi dan Al-Hakim. Al-Hakim kemudian menyatakan bahwa hadits ini shahih berdasarkan syarat Al-Bukhari dan Muslim. Pendapat ini disepakati pula oleh Adz-Dzahabi).

Hadis tersebut menyimpulkan bahwa laki-laki dan perempuan yang belum menikah dilarang berduaan. 

Tidak hanya berduaan saja, laki-laki pun harus menjaga pandangannya dengan lawan jenis, begitu juga sebaliknya.

Hal ini karena dikhawatirkan akan memicu bahaya maupun hal yang tidak diinginkan akan terjadi. 

Dalam hal bepergian pun, wanita juga harus didampingi seorang mahramnya untuk melindungi dirinya dari fitnah dan godaan. 

Berdasarkan pemaparan hadis jelas mengungkapkan bahwa pacaran adalah haram dan tidak boleh dilakukan karena itu akan mengarahkan kepada sebuah perzinahan.

Allah SWT berfirman dalam Al-Quran Surat Al-Isra ayat 32 yang berbunyi:

وَلَا تَقْرَبُوا الزِّنٰىٓ اِنَّهٗ كَانَ فَاحِشَةً ۗوَسَاۤءَ سَبِيْلًا

"Dan janganlah kamu mendekati zina; sesungguhnya zina itu adalah suatu perbuatan yang keji, dan suatu jalan yang buruk." (Q.S. Al-Isra: 32).

Perlu Anda ketahui bahwa pacaran merupakan budaya Barat yang kini banyak diadaptasi dan dilakukan oleh negara-negara lain di belahan dunia, termasuk Indonesia dengan mayoritas salah satu umat Muslim terbanyak di dunia. 

Dalam Islam sendiri, tidak ada dasar dalam Al-Qur’an dan Hadis yang mengajak pada ajaran untuk berpacaran. 

Untuk menghindari perzinahan antara dua orang Muslim yang saling mencintai, cara terbaik yang harus dilakukan sesuai dengan hukum Islam adalah melalui pernikahan. 
Islam menganjurkan apabila seseorang telah mampu untuk menikah, maka segeralah menikah. 

Hal tersebut dilakukan agar manusia tidak terjerumus dalam perbuatan maksiat yang merugikan dirinya sendiri. Ini sesuai dengan hadis berikut:

لَمْ أَرَ لِلْمُتَحَابَّيْنِ مِثْلَ النِّكَاحِ

"Kami tidak pernah tahu solusi untuk dua orang yang saling mencintai, selain pernikahan." (HR.Ibnu Majah). 

Harus ditekankan bahwa pernikahan yang benar tidak dimulai dengan pacaran. 

Akan tetapi mengidentifikasi karakter calon pasangan bisa dilakukan dengan cara yang tidak melanggar hukum Syariah Islam.

Ketika sebuah pernikahan dilangsungkan menurut hukum Syariah Islam, maka sebuah kehidupan rumah tangga akan dilimpahi keberkahan dan berada di bawah perlindungan Allah SWT. 

Rasulullah SAW pun bersabda:

يَا مَعْشَرَ الشَّبَابِ مَنِ اسْتَطَاعَ مِنْكُمُ الْبَاءَةَ فَلْيَتَزَوَّجْ فَإِنَّهُ أَغَضُّ لِلْبَصَرِ وَأَحْصَنُ لِلْفَرْجِ وَمَنْ لَمْ يَسْتَطِعْ فَعَلَيْهِ بِالصَّوْمِ فَإِنَّهُ لَهُ وِجَاءٌ

“Wahai pemuda, barangsiapa di antara kamu memiliki kemampuan, maka menikahlah. Karena sesungguhnya pernikahan dapat menjaga pandangan (dari maksiat), dan menjaga kemaluan (dari persetubuhan yang haram). Barang siapa yang belum mampu melakukannya, hendaknya ia berpuasa karena itu akan menjadi pengendali baginya”. 
`
  await conn.sendMessage(m.chat, {
text: anu,
contextInfo: {
externalAdReply: {  
title: 'H U K U M  P A C A R A N',
body: namebot,
thumbnailUrl: 'https://telegra.ph/file/ab0c55fb05ed4c4c8bd09.jpg',
sourceUrl: '',
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
}
handler.help = ['hukumpacaran']
handler.tags = ['islam']
handler.command = /^(hukumpacaran)$/i

module.exports = handler