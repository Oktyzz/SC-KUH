const fetch = require('node-fetch');
var handler = async (m, { conn, args, usedPrefix, command }) => {
     var tio = await fetch(`https://api.lolhuman.xyz/api/pinterest2?apikey=Akiraa&query=guardian+tales`)
var p = await tio.json()
let url = p.result[Math.floor(Math.random()  *p.result.length)]
  conn.sendFile(m.chat, url, 'loliiiii.jpg', `_*🔖R A N D O M   G U A R D I A N   T A L E S*_` , m, false)
}
handler.help = ['guardiantales']
handler.tags = ['anime']
handler.command = /^(guardiantales)$/i
handler.limit = true;
module.exports = handler;