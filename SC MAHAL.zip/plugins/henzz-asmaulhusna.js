const fetch = require('node-fetch')

let handler = async (m, { conn }) => {
  let apikey = `Akiraa`
  let url = `https://api.lolhuman.xyz/api/asmaulhusna?apikey=Akiraa`
  let res = await fetch(url)
  let json = await res.json()
  if (json.status !== 200) {
    return conn.reply(m.chat, 'Maaf, terjadi kesalahan saat mengambil data dari server', m)
  }
  	conn.chatRead(m.chat)
	conn.sendMessage(m.chat, {
		react: {
			text: '🕒',
			key: m.key,
		}
	})
  let result = json.result
  let caption = `*Asmaul Husna*\n`
  caption += `Index : ${result.index}\n`
  caption += `Latin : ${result.latin}\n`
  caption += `Arab  : ${result.ar}\n`
  caption += `ID    : ${result.id}\n`
  caption += `EN    : ${result.en}`
  let response = await fetch('https://telegra.ph/file/a84e5805d3db4900e9a25.jpg')
  let buffer = await response.buffer()
  conn.sendFile(m.chat, buffer, 'asmaulhusna.jpg', caption.trim(), m)
}

handler.help = ['asmaulhusna']
handler.tags = ['islam']
handler.command = /^asmaulhusna$/i
handler.register = true
handler.limit = true

module.exports = handler