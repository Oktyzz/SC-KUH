const canvafy = require("canvafy");
const fsPromises = require('fs').promises;
const crypto = require("crypto");
const fetch = require("node-fetch");

const Reg = /\|?(.*)([^\w\s])([0-9]*)$/i;

const handler = async (m, {
    conn, text, usedPrefix, command
}) => {
    conn.registrasi = conn.registrasi ? conn.registrasi : {};

    if (conn.registrasi[m.chat]?.[m.sender]) return m.reply('[!] Sedang Dalam Sessi Verikasi');
    let naon = await conn.getName(m.sender)
    let user = global.db.data.users[m.sender];
    if (user.registered === true) throw `(・∀・) Kamu Sudah mempunyai Akun, Ingin keluar dari akun anda??, ketik .unreg <Serial number anda>\n\n*Example:* .unreg 123455\n\nLupa dengan Serial Number anda?? Ketik *.ceksn* untuk melihat serial number anda`;
    const umurRandom = Math.floor(Math.random() * 100) + 1;
    const formatSalah = `*Example:* ${usedPrefix + command} ${naon}.${umurRandom}`;
    if (!Reg.test(text)) throw formatSalah;
    let [_, name, splitter, age] = text.match(Reg);
    if (!name) throw `Tuliskan Nama Mu *${naon}*`;
    if (!age) throw "Berapa Umur mu??";
    age = parseInt(age);
    if (age > 50) throw "Umur Terlalu Tua";
    if (age < 5) throw "Umur Terlalu Muda";

    let sn = crypto.createHash("md5").update(m.sender).digest("hex");
    let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : m.fromMe ? conn.user.jid : m.sender;
    let pp = await conn.profilePictureUrl(who, 'image').catch((_) => "https://telegra.ph/file/1ecdb5a0aee62ef17d7fc.jpg");

    let cap = ` *[VERIFY SUCCESSFULLY]*
    
• *Name:* ${name}
• *Age:* ${age} Old
• *Serial Number (SN):* ${sn}

[!] Note: Tolong Jangan Hilangkan Serial number anda
`;

    const json = await createOtpCanvas(pp);

    let confirm = `             *[PROCESS VERIFY]*\nHalo Kak ${naon}\nBerikut Adalah Kode Otp anda Tolong Masukan Kode otp anda dengan cara Reply Pesan ini!!`;
    let { key } = await conn.sendFile(m.chat, json.image, '', confirm,m, null, {
        fileLength: 4500,
        quoted: m
    });

    conn.registrasi[m.chat] = {
        ...conn.registrasi[m.chat],
        [m.sender]: {
            message: m,
            sender: m.sender,
            otp: json.otp,
            verified: json.verified,
            caption: cap,
            pesan: conn,
            age,
            user,
            name,
            key,
            timeout: setTimeout(() => {
                conn.sendMessage(m.chat, { delete: key });
                delete conn.registrasi[m.chat][m.sender];
            }, 60 * 1000)
        }
    };
}

handler.before = async (m, { conn }) => {
    conn.registrasi = conn.registrasi ? conn.registrasi : {};
    if (m.isBaileys) return;
    if (!conn.registrasi[m.chat]?.[m.sender]) return;
    if (!m.text) return;
    
    let { timeout, otp, verified, message, sender, pesan, caption, user, name, age, key } = conn.registrasi[m.chat]?.[m.sender];
    
    if (m.id === message.id) return;
    if (m.id === key.id) return;

    if (m.text == otp) {
        user.name = name.trim();
        user.age = age;
        user.regTime = +new Date;
        user.registered = true;
        let benar = `Kode Otp Anda Cocok!!\nSelamat Kak ${m.sender.split('@')[0]} Kamu Telah Selasai Verifikasi`;
        conn.reply(m.chat, benar, m)
        pesan.sendFile(m.chat, verified, '', caption, m, { quoted: m });
        clearTimeout(timeout);
        pesan.sendMessage(m.chat, { delete: key });
        delete conn.registrasi[m.chat]?.[m.sender];
    } else {
        m.reply(`Kode Anda Tidak cocok\nMaaf Kak ${m.sender.split('@')[0]} Proses Verifikasi Anda gagal, silahkan coba lagi^^`);
        clearTimeout(timeout);
        pesan.sendMessage(m.chat, { delete: key });
        delete conn.registrasi[m.chat]?.[m.sender];
    }
}

handler.help = ["daftar", "register"].map(v => v + " <nama>.<umur>");
handler.tags = ["xp"];
handler.command = /^(register|verify|daftar|verif)$/i;

module.exports = handler;

function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)];
}

function isNumber(x) {
    return !isNaN(x);
}

function generateRandomCharacter() {
    const characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    return characters[Math.floor(Math.random() * characters.length)];
}

async function createOtpCanvas(avatar) {
    const codetext = Array.from({ length: 6 }, generateRandomCharacter).join('');
    const captchaBuffer = await new canvafy.Captcha()
        .setBackground("image", "https://i3.wp.com/tmpfiles.org/dl/2378984/tmp.jpg")
        .setCaptchaKey(codetext.toString())
        .setBorder("#FFEEB7")
        .setOverlayOpacity(1.0)
        .build();
    const securityBuffer = await new canvafy.Security()
        .setAvatar(avatar)
        .setBackground("image", "https://i3.wp.com/tmpfiles.org/dl/2378984/tmp.jpg")
        .setCreatedTimestamp(Date.now())
        .setSuspectTimestamp(1)
        .setBorder("#FFEEB7")
        .setLocale("id")
        .setAvatarBorder("#FFEEB7")
        .setOverlayOpacity(1.0)
        .build();
    return {
        image: captchaBuffer,
        otp: codetext,
        verified: securityBuffer
    };
};