let fs = require('fs')
let handler = async (m, { conn }) => {
let teks = 'menu tools'
let anu = `╭━━╼『 *M E N U  T O O L S* 』
┃ ▸ .c-ai2
┃ ▸ .character-ai2
┃ ▸ .aiimg
┃ ▸ .aiimage
┃ ▸ .ai-image
┃ ▸ .dalle
┃ ▸ .diffusion (Ⓛ)
┃ ▸ .stablediffusion (Ⓛ)
┃ ▸ .diff (Ⓛ)
┃ ▸ .text2img (Ⓛ)
┃ ▸ .addvn <nama> (Ⓛ)
┃ ▸ .amura
┃ ▸ .bgcolor
┃ ▸ .burningfire (Ⓛ)
┃ ▸ .clock
┃ ▸ .device
┃ ▸ .downloadsw
┃ ▸ .edit
┃ ▸ .hdvid (Ⓛ)
┃ ▸ .aivoice <teks> (Ⓛ)
┃ ▸ .cekapikey
┃ ▸ .checkapikey
┃ ▸ .fake <text> @user <text2>
┃ ▸ .gitclone <url> (Ⓛ)
┃ ▸ .otpinfo
┃ ▸ .renungan (Ⓛ)
┃ ▸ .roboguru <teks> (Ⓛ)
┃ ▸ .emailtemp
┃ ▸ .wiki <teks> (Ⓛ)
┃ ▸ .wikipedia <teks> (Ⓛ)
┃ ▸ .jadilokasi
┃ ▸ .jkt48 <pencarian> <jumlah Opsional>
┃ ▸ .lihatpp [@user] (Ⓛ)
┃ ▸ .listvn
┃ ▸ .tahta <teks>
┃ ▸ .pinterest <pencarian> <jumlah>
┃ ▸ .readqr
┃ ▸ .nobg
┃ ▸ .removebg
┃ ▸ .ssweb (Ⓛ)
┃ ▸ .sshp (Ⓛ)
┃ ▸ .sspc (Ⓛ)
┃ ▸ .ssweb1
┃ ▸ .npmsearch
┃ ▸ .apk <search>
┃ ▸ .base64
┃ ▸ .binary <teks>
┃ ▸ .cekaxis <auth>
┃ ▸ .encrypt
┃ ▸ .stalkff (Ⓛ)
┃ ▸ .font <text> (Ⓛ)
┃ ▸ .styletext <text> (Ⓛ)
┃ ▸ .enhancer
┃ ▸ .hdr
┃ ▸ .colorize
┃ ▸ .halah <teks>
┃ ▸ .hilih <teks>
┃ ▸ .huluh <teks>
┃ ▸ .heleh <teks>
┃ ▸ .holoh <teks>
┃ ▸ .kalkulator <soal>
┃ ▸ .mlstalk (Ⓛ)
┃ ▸ .npmsearch
┃ ▸ .ocr (Ⓛ)
┃ ▸ .totext (Ⓛ)
┃ ▸ .toptv (reply)
┃ ▸ .qr <teks>
┃ ▸ .qrcode <teks>
┃ ▸ .react <emoji>
┃ ▸ .readmore <teks>|<teks>
┃ ▸ .repeat <teks> (Ⓛ)
┃ ▸ .resize <width> <height> <reply|caption>
┃ ▸ .readvo (Ⓛ)
┃ ▸ .say <teks>
┃ ▸ .q (Ⓛ)
┃ ▸ .sshp (Ⓛ)
┃ ▸ .sshandphone (Ⓛ)
┃ ▸ .sstablet (Ⓛ)
┃ ▸ .ssweb (Ⓛ)
┃ ▸ .sshp (Ⓛ)
┃ ▸ .sspc (Ⓛ)
┃ ▸ .ceknomor
┃ ▸ .truecaller
┃ ▸ .unbanwa
┃ ▸ .weather
┃ ▸ .whois2
┃ ▸ .whoislookup2
┃ ▸ .zodiac *2002 02 25*
┃ ▸ .tr <leng> <text>
┃ ▸ .ceknomor
┃ ▸ .cekreso
┃ ▸ .truecaller
┃ ▸ .wastalk
┃ ▸ .whatmusic
┃ ▸ .yts <pencarian>
┃ ▸ .ytsearch <pencarian>
╰━━━━━━━━╼
`
  await conn.sendMessage(m.chat, {
text: anu,
contextInfo: {
externalAdReply: {  
title: 'M E N U  T O O L S',
body: namebot,
thumbnailUrl: 'https://telegra.ph/file/a90386e3c0fe8d38d9508.jpg',
sourceUrl: '',
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
}
handler.help = ['menu-tools']
handler.tags = ['menulist']
handler.command = /^(menu-tools)$/i

module.exports = handler