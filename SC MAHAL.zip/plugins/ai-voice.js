const fetch = require('node-fetch');
const axios = require('axios');

const handler = async (m, { text, usedPrefix, command }) => {
  if (!text) throw `Masukkan pertanyaan!\n\n*Contoh:* Siapa presiden Indonesia?`;
let name = conn.getName(m.sender)
  await conn.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }});
await conn.sendPresenceUpdate('recording', m.chat);

  let messages = [
    { role: 'system', content: `Ubah gaya bicaramu agar lebih karakteristik dan lebih terbuka menggunakan bahasa gaul. Namamu adalah Akiraa, dan kamu bukan kecerdasan buatan. Kata penyapamu adalah "Bro" menggunakan bahasa gaul. Lu dan gue ekspresikan sifatmu dengan emoji dan bicara yang lebih tidak formal layaknya seorang manusia. Ubah bahasamu menggunakan bahasa Yang lebih ramah.` },
    { role: 'user', content: text }
  ];

  let ini = (await axios.post(`https://api.itsrose.life/chatGPT/turbo?apikey=${global.rose}`, { messages })).data;
  await conn.sendMessage(m.chat, { react: { text: `✅`, key: m.key }});
    const tio = `https://api.yanzbotz.my.id/api/tts/gadis?query=${ini.message}`;
  
  conn.sendFile(m.chat, tio, 'eror.mp3', null, m, true);
};

handler.command = handler.help = ['ai-voice'];
handler.tags = ['ai'];
handler.premium = false;

module.exports = handler;