/*Sc Akiraa Bot By Bang syaii
*Whatsapp: wa.me/6283842839555
*Credit: © AkiraaBot 2023-2024
*/
const moment = require('moment');
const os = require('os');
const fetch = require('node-fetch')
const { performance } = require('perf_hooks');
const canvafy = require ('canvafy')
let handler = async m => {
let wait = '*ʟ ᴏ ᴀ ᴅ ɪ ɴ ɢ. . .*'
const arr = [
    { text: "*ʟ ᴏ ᴀ ᴅ ɪ ɴ ɢ. . .*", timeout: 100 },
    { text: "*□□■■■■■■■■\n             𝟷𝟶٪*", timeout: 150 },
    { text: "*■■□□■■■■■■\n             𝟹𝟶٪*", timeout: 200 },
    { text: "*■■■■□□■■■■\n             𝟻𝟶٪*", timeout: 250 },
    { text: "*■■■■■■□□■■\n             𝟾𝟶٪*", timeout: 300 },
    { text: "*■■■■■■■■□□\n             𝟷𝟶𝟶٪*", timeout: 350 },
    { text: "*𝚂𝙰𝙽𝚉𝚈 𝙼𝚄𝙻𝚃𝙸𝙳𝙴𝚅𝙸𝙲𝙴*", timeout: 400 },
    { text: `*ʟ ᴏ ᴀ ᴅ ɪ ɴ ɢ  ᴄ ᴏ ᴍ ᴘ ʟ ᴇ ᴛ ᴇ. . .*`, timeout: 450 }
  ];

  const lll = await conn.sendMessage(m.chat, { text: wait }, { quoted: m });

  for (let i = 0; i < arr.length; i++) {
    await new Promise(resolve => setTimeout(resolve, arr[i].timeout));
    await conn.relayMessage(m.chat, {
      protocolMessage: {
        key: lll,
        type: 14,
        editedMessage: {
          conversation: arr[i].text
        }
      }
    }, {});
  }
  let krtu = `web`
  let name = await conn.getName(m.sender)
let pp = await conn.profilePictureUrl(m.sender, 'image').catch((_) => "https://telegra.ph/file/191255466221149ca48d0.jpg");
  // Menghitung waktu saat ini
  let time = moment().format('DD MMMM YYYY, HH:mm:ss');
  
  // Mengambil informasi server
  let serverInfo = `*ᴏᴋᴛᴢ - ᴍᴅ* ᴊᴜɢᴀ ᴍᴇɴᴊᴀɢᴀ ᴘʀɪᴠᴀꜱɪ ᴘᴇɴɢɢᴜɴᴀ ᴅᴇɴɢᴀɴ ᴍᴇɴɢʜᴀɴᴄᴜʀᴋᴀɴ ᴅᴀᴛᴀ ʏᴀɴɢ ᴅɪꜱɪᴍᴘᴀɴ ꜱᴇᴛɪᴀᴘ ᴍɪɴɢɢᴜ, ᴍᴇᴍᴀꜱᴛɪᴋᴀɴ ᴅᴀᴛᴀ ᴀɴᴅᴀ ᴛᴇᴛᴀᴘ ᴀᴍᴀɴ ᴅᴀɴ ᴘʀɪʙᴀᴅɪ.`;

  // Menghitung runtime
  let start = performance.now();
  // Kode yang ingin dihitung runtime-nya
  let end = performance.now();
  let runtime = (end - start).toFixed(2); conn.sendPresenceUpdate('composing',m.chat)
  let text = `
*ʜᴀʟʟᴏ ᴋᴀᴋ👋.* ɴᴀᴍᴀ ꜱᴀyᴀ ᴀᴅᴀʟᴀʜ *ᴏᴋᴛᴢ - ʙᴏᴛ* ʙᴏᴛ ʙʏ *ᴏᴋᴛᴢ*

ʙᴏᴛ ɪɴɪ ᴅᴀᴘᴀᴛ ᴅɪɢᴜɴᴀᴋᴀɴ sᴇʙᴀɢᴀɪ *ᴇᴅᴜᴋᴀsɪ ᴘᴇʟᴀᴊᴀʀᴀɴ*, *ᴜɴᴅᴜʜᴀɴ ᴍᴇᴅɪᴀ*, *ɢᴀᴍᴇ*, *ᴘᴇɴᴊᴀɢᴀ ɢʀᴜᴘ*, *ᴅᴀɴ ʟᴀɪɴɴʏᴀ* ʏᴀɴɢ ᴅᴀᴘᴀᴛ ᴍᴇᴍʙᴜᴀᴛ ᴋᴀᴍᴜ ʟᴇʙɪʜ ᴍᴜᴅᴀʜ ᴜɴᴛᴜᴋ ᴍᴇɴᴊᴀʟᴀɴɪ ʜᴀʀɪ-ʜᴀʀɪ:>

╭  ◦ ᴄʀᴇᴀᴛᴏʀ: *ᴏᴋᴛᴢ*
│  ◦ ᴡʜᴀᴛsᴀᴘᴘ: *wa.me/12679068479*
╰  ◦ ᴘʀᴇғɪx: *.*

ᴊɪᴋᴀ ᴀᴅᴀ ᴍᴀsᴀʟᴀʜ ᴅᴀʟᴀᴍ ᴘᴇɴɢɢᴜɴᴀᴀɴ sɪʟᴀʜᴋᴀɴ ʜᴜʙᴜɴɢɪ ᴄʀᴇᴀᴛᴏʀ ᴜɴᴛᴜᴋ ᴍᴇɴᴀɴʏᴀᴋᴀɴ *.ᴏᴡɴᴇʀ*

┌ ◦ ᴍᴇɴᴀᴍᴘɪʟᴋᴀɴ ғɪᴛᴜʀ ʙᴏᴛ: *.ᴀʟʟᴍᴇɴᴜ*
└ ◦ ᴍᴇɴᴀᴍᴘɪʟᴋᴀɴ ᴍᴇɴᴜʟɪꜱᴛ : *.ᴍᴇɴᴜʟɪꜱᴛ*

ʜᴀʀᴀᴘ ᴜɴᴛᴜᴋ ʙᴇʀɢᴀʙᴜɴɢ ɢʀᴏᴜᴘ ʙᴏᴛ ᴀɢᴀʀ ᴍᴇɴɢᴇᴛᴀʜᴜɪ ɪɴғᴏʀᴍᴀsɪ ʙᴏᴛ ᴊɪᴋᴀ *ᴇʀʀᴏʀ/ʙᴀɴɴᴇᴅ*`;

  const fkontak = {
    "key": {
      "fromMe": false,
      "participant": "0@s.whatsapp.net",
      "remoteJid": "status@broadcast",
      "id": "Halo"
    },
    "message": {
      "contactMessage": {
        "displayName": "Sy",
        "vcard": `BEGIN:VCARD\nVERSION:3.0\nN:Sy;Bot;;;\nFN:y\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
      }
    }
  };
let p = await new canvafy.Security()
. setAvatar (pp)
. setBackground ("color","#FFDF00")
. setLocale ("id")
. setOverlayOpacity (1.0)
. setAvatarBorder ("#fff")
   .setCreatedTimestamp(Date.now())
        .setSuspectTimestamp(1)
.build()
conn.sendFile(m.chat, p, '', text, m, null, {
  fileLength: '450000000000000000',
  contextInfo: {
    externalAdReply: {
      showAdAttribution: true,
      mediaType: 1,
      description: wm,
      title: `Halo Kak ${name}`,
      body: wm2,
renderLargerThumbnail: true,
      thumbnail: await (await fetch (`https://telegra.ph/file/191255466221149ca48d0.jpg`)).buffer(),
      sourceUrl: sig
    }
  }
})
 conn.sendFile(m.chat, './mp3/menuu.mp3', '', null, m, true,)
if (/^(allmenu)/i.test(m.text)) {
        m.reply(wait)

      }
}

handler.help = ['menu']
handler.tags = ['main']
handler.command = /^(menu)$/i
handler.limit = true
handler.register = true
module.exports = handler

//The Best Rpg Bot