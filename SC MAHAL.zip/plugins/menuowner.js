let fs = require('fs')
let handler = async (m, { conn }) => {
let teks = 'menu owner'
let anu = `╭━━╼『 *M E N U  O W N E R* 』
┃ ▸ .addlogs <apa>
┃ ▸ .addlimit @user <amount>
┃ ▸ .mods *@tag*
┃ ▸ .prem *@tag|days*
┃ ▸ .addprems <nomor>
┃ ▸ .addsewa <hari>
┃ ▸ .addxp @user <amount>
┃ ▸ .backupme
┃ ▸ .banchat
┃ ▸ .ban
┃ ▸ .ban
┃ ▸ .bcgcbot <teks>
┃ ▸ .broadcastimg <teks>
┃ ▸ .bcimg <teks>
┃ ▸ .broadcast <teks>
┃ ▸ .bc <teks>
┃ ▸ .broadcast <teks>
┃ ▸ .bc <teks>
┃ ▸ .clearsession
┃ ▸ .colong <reply sticker>
┃ ▸ .clearsession
┃ ▸ .dev
┃ ▸ .enable <option>
┃ ▸ .disable <option>
┃ ▸ .getdatabase
┃ ▸ .getplugin [filename]
┃ ▸ .pushkontak
┃ ▸ .matikanbot
┃ ▸ .sf <teks>
┃ ▸ .df <teks>
┃ ▸ .promote @user
┃ ▸ .reset <62xxx>
┃ ▸ .restart
┃ ▸ .otransfer
┃ ▸ .self
┃ ▸ .public
┃ ▸ .setbotbio
┃ ▸ .setnamebot <teks>
┃ ▸ .setpp
┃ ▸ .setthumb
┃ ▸ .savefile <path>
┃ ▸ .sf <path>
┃ ▸ .simulate <event> <@mention>
┃ ▸ .titlein <nama>
┃ ▸ .addusr
┃ ▸ .delusr
┃ ▸ .listusr
┃ ▸ .detusr
┃ ▸ .addsrv
┃ ▸ .delsrv
┃ ▸ .listsrv
┃ ▸ .detsrv
┃ ▸ .reinstall
┃ ▸ .updatesrv
┃ ▸ .startsrv
┃ ▸ .stopsrv
┃ ▸ .restartsrv
┃ ▸ .unban
┃ ▸ .unban
┃ ▸ .warn @tag
╰━━━━━━━━╼
`
  await conn.sendMessage(m.chat, {
text: anu,
contextInfo: {
externalAdReply: {  
title: 'M E N U  O W N E R',
body: namebot,
thumbnailUrl: 'https://telegra.ph/file/844cf3b7ba3deb7537b9a.jpg',
sourceUrl: '',
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
}
handler.help = ['menu-owner']
handler.tags = ['menulist']
handler.command = /^(menu-owner)$/i

module.exports = handler