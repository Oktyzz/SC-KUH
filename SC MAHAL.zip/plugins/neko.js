const fetch = require('node-fetch');

let luna = async (m, { conn }) => {
  try {
    const response = await fetch('https://api.waifu.pics/sfw/neko');
    const result = await response.json();
    conn.sendFile(m.chat, result.url,'', wm, m);
  } catch (error) {
    console.log(error);
    conn.reply(m.chat, 'Terjadi kesalahan saat mencari gambar neko', m);
  }
};

luna.command = ['neko'];
luna.tags = ['anime'];
luna.help = ['neko'];

module.exports = luna;