let fs = require('fs')
let handler = async (m, { conn }) => {
let teks = 'menu exp'
let anu = `╭━━╼『 *M E N U  E X P* 』
┃ ▸ .daftar <nama>.<umur>
┃ ▸ .register <nama>.<umur>
┃ ▸ .donasi
┃ ▸ .donate
┃ ▸ .buylimit <jumlah>
┃ ▸ .limit [@user]
┃ ▸ .bank
┃ ▸ .dompet
┃ ▸ .dompet @user
┃ ▸ .tomoney <jumlah>
╰━━━━━━━━╼
`
  await conn.sendMessage(m.chat, {
text: anu,
contextInfo: {
externalAdReply: {  
title: 'M E N U  E X P',
body: namebot,
thumbnailUrl: 'https://telegra.ph/file/7d721afd2a784f8e1d813.jpg',
sourceUrl: '',
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
}
handler.help = ['menu-exp']
handler.tags = ['menulist']
handler.command = /^(menu-exp)$/i

module.exports = handler