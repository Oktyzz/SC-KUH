var fetch = require('node-fetch');
var handler = async (m, {
 text, 
 usedPrefix, 
 command
 }) => {
  if (!text) {
    throw `Halo kak`
  }

  // Cek apakah sedang ada sesi chat atau tidak
  if (conn.game && conn.game.isChatting) {
    // Kirim pertanyaan ke sesi chat yang sedang berlangsung
    conn.game.chatHandler(m, text);
  } else {
    // Jika tidak ada sesi chat, lakukan request ke API simi
    var apii = await fetch(`https://api.lolhuman.xyz/api/simi?apikey=Akiraa&text=${text}&badword=true`)
    var js = await apii.json()
    await m.reply(js.result)
if (js.result) {
    let audio = await fetch(`https://xzn.wtf/api/tts-anime?text=${js.result}&lang=mix&voice=paimon&speed=0.65&symbol=N&apikey=viva`);
    let json = await audio.json();
    conn.sendFile(m.chat, json.data.url, '', null, m, true);
  }
  return true;
  }
}

handler.command = handler.help = ['simi','chatbot'];
handler.tags = ['info'];
handler.premium = false
module.exports = handler;