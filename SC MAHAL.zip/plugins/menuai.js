let fs = require('fs')
let handler = async (m, { conn }) => {
let teks = 'menu ai'
let anu = `╭━━╼『 *M E N U  A I* 』
┃ ▸ .ai (Ⓛ)
┃ ▸ .openai (Ⓛ)
┃ ▸ .bard (Ⓛ)
┃ ▸ .blackbox
┃ ▸ .aicode (Ⓛ)
┃ ▸ .codegen (Ⓛ)
┃ ▸ .deepfake
┃ ▸ .differentme  (Ⓟ)
┃ ▸ .getmodel  (Ⓟ)
┃ ▸ .hairstyle (Ⓛ)
┃ ▸ .aihutao
┃ ▸ .img2img (Ⓛ) (Ⓟ)
┃ ▸ .makerdif (Ⓛ)
┃ ▸ .modeldif
┃ ▸ .prompter  (Ⓟ)
┃ ▸ .ai-voice
┃ ▸ .aiyamada
┃ ▸ .aibocchi
┃ ▸ .jojo  (Ⓟ)
┃ ▸ .anime2d  (Ⓟ)
┃ ▸ .cartoon3d  (Ⓟ)
┃ ▸ .pretty  (Ⓟ)
┃ ▸ .romancecomic  (Ⓟ)
┃ ▸ .maid  (Ⓟ)
┃ ▸ .superhero  (Ⓟ)
┃ ▸ .watercolor  (Ⓟ)
┃ ▸ .doodle  (Ⓟ)
┃ ▸ .americacomic  (Ⓟ)
┃ ▸ .starrygirl  (Ⓟ)
┃ ▸ .aijawir
┃ ▸ .cai (Ⓛ)
┃ ▸ .c-ai
┃ ▸ .promt
┃ ▸ .jadianime (Ⓛ)
┃ ▸ .jadizombie (Ⓛ)
┃ ▸ .turnme
┃ ▸ .voicevox (Ⓛ)
┃ ▸ .kobo (Ⓛ)
┃ ▸ .color (Ⓛ)
┃ ▸ .warnain (Ⓛ)
╰━━━━━━━━╼
`
  await conn.sendMessage(m.chat, {
text: anu,
contextInfo: {
externalAdReply: {  
title: 'M E N U  A I',
body: namebot,
thumbnailUrl: 'https://telegra.ph/file/7c6bb5d33b8b72464bdca.jpg',
sourceUrl: '',
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
}
handler.help = ['menu-ai']
handler.tags = ['menulist']
handler.command = /^(menu-ai)$/i

module.exports = handler