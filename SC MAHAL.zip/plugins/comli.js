let handler = m => m

handler.all = async function (m, { isBlocked }) {
  if (isBlocked) return
  if (m.text.toLowerCase() === '.coli' || m.text.toLowerCase() === '.comli' || m.text.toLowerCase() === 'coli') {
 (async() => {
const arr = [
  "*MENONTON BOKP*",
  "*MULAI BERDIRI*",
  "*MULAI MENGOCOK*",
  "රඩ",
  "රධ",
  "🤌Ɑ͞ ̶͞ ̶͞ ඩ",
  "Ɑ͞ ̶͞ ̶͞👌 ﻝﮞ",
  "🤌Ɑ͞ ̶͞ ̶͞ ඩ",
  "Ɑ͞ ̶͞ ̶͞👌 ﻝﮞ",
  "🤌Ɑ͞ ̶͞ ̶͞ ඩ",
  "Ɑ͞ ̶͞ ̶͞👌 ﻝﮞ",
  "🤌Ɑ͞ ̶͞ ̶͞ ඩ",
  "Ɑ͞ ̶͞ ̶͞👌 ﻝﮞ",
  "🤌Ɑ͞ ̶͞ ̶͞ ඩ",
  "Ɑ͞ ̶͞ ̶͞👌 ﻝﮞ",
  "🤌Ɑ͞ ̶͞ ̶͞ ඩ",
  "Ɑ͞ ̶͞ ̶͞👌 ﻝﮞ",
  "🤌Ɑ͞ ̶͞ ̶͞ ඩ",
  "Ɑ͞ ̶͞ ̶͞👌 ﻝﮞ",
  "💦Ɑ͞ ̶͞ ̶͞ ඩ",
  "💦රධ",
  "CROTTT",
  "HASIL MENGOCOK ANDA \n SELAMAT ANDA MENDAPATKAN \n \n EXP : 80000 \n BALANCE : 10000 \n LIMIT : 10"
];

const { key } = await conn.sendMessage(m.chat, { text: '*MAIN HP*' }, { quoted: m});

for (let i = 0; i < arr.length; i++) {
  await new Promise(resolve => setTimeout(resolve, 1000));
  await conn.sendMessage(m.chat, { text: arr[i], edit: key });
}})()

   }
}

module.exports = handler