let fs = require('fs')
let handler = async (m, { conn }) => {
let teks = 'menu anonymous'
let anu = `╭━━╼『 *M E N U  A N O N Y M O U S* 』
┃ ▸ .start,leave,next
┃ ▸ .menfess <nomor|nama pengirim|pesan>
┃ ▸ .menfes <nomor|nama pengirim|pesan>
╰━━━━━━━━╼
`
  await conn.sendMessage(m.chat, {
text: anu,
contextInfo: {
externalAdReply: {  
title: 'M E N U  A N O N Y M O U S',
body: namebot,
thumbnailUrl: 'https://telegra.ph/file/32159f128832060c8b08d.jpg',
sourceUrl: '',
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
}
handler.help = ['menu-anonymous']
handler.tags = ['menulist']
handler.command = /^(menu-anonymous)$/i

module.exports = handler