let { mediafiredl } = require("@bochilteam/scraper");
let handler = async (m, { conn }) => {
  await conn.reply(m.chat, `Acaca gimana😭 gini bukan sih😆`, m);
	let lol = [
		"https://www.mediafire.com/file/6kewbg0ir86zfgz/Acaca.mp3/file",
	];
	let anu = lol[Math.floor(Math.random() * lol.length)];
	
	let lol2 = [
`${anu}`, 
"https://www.mediafire.com/file/6kewbg0ir86zfgz/Acaca.mp3/file",
]

let anu2 = lol2[Math.floor(Math.random() * lol2.length)];
	
	let res = await mediafiredl(anu2);
	let { url, url2, filename, ext, aploud, filesize, filesizeH } = res;
	await conn.sendFile(m.chat, url, filename, '```Success...\nDont forget to donate```', m, {
		asDocument: false,
	});
};

handler.customPrefix = /^acaca$/i;
handler.command = new RegExp();

module.exports = handler