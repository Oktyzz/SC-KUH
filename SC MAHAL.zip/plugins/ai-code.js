const fetch = require('node-fetch');

const handler = async (m, { conn, text }) => {
  if (!text) throw 'Masukkan teksnya';
  m.reply('Menunggu...');
  const response = await fetch(`https://vihangayt.me/tools/kodezi?q=${encodeURIComponent(text)}&lang=javascript`);
  const data = await response.json();
  const hasil = `
[AI CODE GENERATOR]
${data.data}
`;
  m.reply(hasil);
};
handler.help= ['aicode', 'codegen'];
handler.command = ['aicode', 'codegen'];
handler.tags = ['ai'];
handler.limit = true;

module.exports = handler;