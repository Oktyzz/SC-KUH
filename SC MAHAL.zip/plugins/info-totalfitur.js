let fs = require ('fs')
let handler = async (m, { conn, args, command }) => {
let fitur = Object.values(plugins).filter(v => v.help && !v.disabled).map(v => v.help).flat(1)
let totalf = Object.values(global.plugins).filter(
    (v) => v.help && v.tags
  ).length;
let cap = `Total Bot Features Currently: \n*🔖 Plugins :* ±${totalf} Plugins Files\n*🔖 Features :* ±${fitur.length} Menu`  
conn.relayMessage(m.chat,  {
    requestPaymentMessage: {
      currencyCodeIso4017: 'US',
      amount10000: totalf,
      requestFrom: m.sender,
      noteMessage: {
      extendedTextMessage: {
     text: cap,
      contextInfo: {
      externalAdReply: {
      showAdAttribution: true
      }}}}}}, {})
}  
handler.help = ['totalfitur']
handler.tags = ['info']
handler.command = ['totalfitur']
module.exports = handler