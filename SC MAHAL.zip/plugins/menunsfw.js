let fs = require('fs')
let handler = async (m, { conn }) => {
let teks = 'menu nsfw'
let anu = `╭━━╼『 *M E N U. N S F W* 』
┃ ▸ .blowjob (Ⓛ)
┃ ▸ .hentai  (Ⓟ)
┃ ▸ .pussy  (Ⓟ)
┃ ▸ .lolicon (Ⓛ)
┃ ▸ .ometv  (Ⓟ)
┃ ▸ .onlyfans  (Ⓟ)
┃ ▸ .paptt (Ⓛ) (Ⓟ)
╰━━━━━━━━╼
`
  await conn.sendMessage(m.chat, {
text: anu,
contextInfo: {
externalAdReply: {  
title: 'M E N U  N S F W',
body: namebot,
thumbnailUrl: 'https://telegra.ph/file/e34821064ec2a52002d3e.jpg',
sourceUrl: '',
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
}
handler.help = ['menu-nsfw']
handler.tags = ['menulist']
handler.command = /^(menu-nsfw)$/i

module.exports = handler