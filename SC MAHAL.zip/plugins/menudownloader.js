let fs = require('fs')
let handler = async (m, { conn }) => {
let teks = 'menu downloader'
let anu = `╭━━╼『 *M E N U  D O W N L O A D E R* 』
┃ ▸ .capcut (Ⓛ)
┃ ▸ .cc (Ⓛ)
┃ ▸ .capcutdl (Ⓛ)
┃ ▸ .ccdl (Ⓛ)
┃ ▸ .youtube (Ⓛ)
┃ ▸ .douyin (Ⓛ)
┃ ▸ .soundcloud <url>
┃ ▸ .threads (Ⓛ)
┃ ▸ .threadsdl (Ⓛ)
┃ ▸ .tiktok (Ⓛ)
┃ ▸ .tiktoksearch (Ⓛ)
┃ ▸ .facebook <url>
┃ ▸ .mediafire <url>  (Ⓟ)
┃ ▸ .playvideo
┃ ▸ .gore <text>
┃ ▸ .instagram (Ⓛ)
┃ ▸ .ig (Ⓛ)
┃ ▸ .pindl (Ⓛ)
┃ ▸ .pinterest <keyword>
┃ ▸ .play3 (Ⓛ)
┃ ▸ .play <query>
┃ ▸ .play
┃ ▸ .snack <url>
┃ ▸ .spotifyfdl
┃ ▸ .spotify
┃ ▸ .sptdl
┃ ▸ .spotifysearch (Ⓛ)
┃ ▸ .tiktokslide
┃ ▸ .xnxxdown (Ⓛ) (Ⓟ)
┃ ▸ .ytmp3
┃ ▸ .ytdl <query>
┃ ▸ .yts <pencarian>
┃ ▸ .ytsearch <pencarian>
┃ ▸ .ytmp4
╰━━━━━━━━╼
`
  await conn.sendMessage(m.chat, {
text: anu,
contextInfo: {
externalAdReply: {  
title: 'M E N U  D O W N L O A D E R',
body: namebot,
thumbnailUrl: 'https://telegra.ph/file/83c431c09fea864138cc6.jpg',
sourceUrl: '',
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
}
handler.help = ['menu-downloader']
handler.tags = ['menulist']
handler.command = /^(menu-downloader)$/i

module.exports = handler