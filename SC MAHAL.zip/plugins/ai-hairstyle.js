const axios = require("axios");
const fs = require("fs");

let handler = async (m, { conn, usedPrefix, command, text }) => {
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || "";
  if (!mime) throw "Poto nya mana";
  if (!text)
    throw "Masukan Hair Id Yang Di Inginkan Dan Fotonya Harus Jelas\n\nList Hair ID Nya:\n- fishtail_girl\n- mermaid_girl\n- bluntbangs_girl\n- curtains_girl\n- school_girl\n- straight_girl\n- shorthair_girl\n- shor_man\n- k_man\n- natural_man\n- side_man\n- slicked_man\n- comma_man\n\nContoh: .hairstyle k_man";
  m.reply(wait);
  let media = await q.download();
  const form = new FormData();
  form.append("file", media.buffer, "image.jpg");
  const { data } = await axios.post("http://api.itsrose.life/image/hair_style", form, {
    params: {
      hair_id: text,
      json: true,
      apikey: "ea4723c36d4979aa7bc2b06f",
    },
  }).catch((e) => e?.response);
  const { status, message } = data;
  
  if (!status) {
    return console.error(message);
  }
  const { result } = data;
  console.log(result);
  const buffer = Buffer.from(result.base64Image, "base64");
  await conn.sendFile(m.chat, buffer, "conco.jpg", "Nih Kak >_<", m);
};
handler.help = ["hairstyle"];
handler.tags = ["ai"];
handler.command = /^(hairstyle)$/i;
handler.limit = true;

module.exports = handler;