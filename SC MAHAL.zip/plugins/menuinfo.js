let fs = require('fs')
let handler = async (m, { conn }) => {
let teks = 'menu info'
let anu = `╭━━╼『 *M E N U  I N F O* 』
┃ ▸ .simi
┃ ▸ .chatbot
┃ ▸ .anime <nama anime>
┃ ▸ .bug <laporan>
┃ ▸ .report <laporan>
┃ ▸ .character <teks>
┃ ▸ .setsetcmd <teks>  (Ⓟ)
┃ ▸ .database
┃ ▸ .user
┃ ▸ .donasi
┃ ▸ .donate
┃ ▸ .about
┃ ▸ .detile
┃ ▸ .aboutbot
┃ ▸ .tentang
┃ ▸ .detail
┃ ▸ .infobot
┃ ▸ .owner
┃ ▸ .creator
┃ ▸ .uptime
┃ ▸ .totalfitur
┃ ▸ .listprem (Ⓛ)
┃ ▸ .ping
┃ ▸ .speed
┃ ▸ .pingme (Ⓛ)
┃ ▸ .readvo
┃ ▸ .server
┃ ▸ .speedtest
┃ ▸ .status
┃ ▸ .statusbot
┃ ▸ .tebakumur
╰━━━━━━━━╼
`
  await conn.sendMessage(m.chat, {
text: anu,
contextInfo: {
externalAdReply: {  
title: 'M E N U  I N F O',
body: namebot,
thumbnailUrl: 'https://telegra.ph/file/844cf3b7ba3deb7537b9a.jpg',
sourceUrl: '',
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
}
handler.help = ['menu-info']
handler.tags = ['menulist']
handler.command = /^(menu-info)$/i

module.exports = handler