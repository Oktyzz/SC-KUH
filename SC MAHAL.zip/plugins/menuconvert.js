let fs = require('fs')
let handler = async (m, { conn }) => {
let teks = 'menu convert'
let anu = `╭━━╼『 *M E N U  C O N V E R T* 』
┃ ▸ .dadu
┃ ▸ .emojimix (Ⓛ)
┃ ▸ .getexif
┃ ▸ .smeta  (Ⓟ)
┃ ▸ .qc
┃ ▸ .stickermeme <teks>|<teks>
┃ ▸ .sticker (Ⓛ)
┃ ▸ .stickanime  (Ⓟ)
┃ ▸ .animestick  (Ⓟ)
┃ ▸ .smim <teks atas>|<teks bawah>
┃ ▸ .tovideo (reply)
┃ ▸ .stikertelegram <url> (Ⓛ) (Ⓟ)
┃ ▸ .wm
┃ ▸ .watermark
┃ ▸ .toimg (reply)
┃ ▸ .tourl <reply image>
╰━━━━━━━━╼
`
  await conn.sendMessage(m.chat, {
text: anu,
contextInfo: {
externalAdReply: {  
title: 'M E N U  C O N V E R T',
body: namebot,
thumbnailUrl: 'https://telegra.ph/file/582627a2c58f9b408d064.jpg',
sourceUrl: '',
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
}
handler.help = ['menu-convert']
handler.tags = ['menulist']
handler.command = /^(menu-convert)$/i

module.exports = handler