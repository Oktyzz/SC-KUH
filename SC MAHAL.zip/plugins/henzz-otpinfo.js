let fs = require('fs')
let handler = async (m, { conn }) => {
let teks = 'info otp'
let anu = `🍟 *Daftar Negara dan Operator OTP* :
ID	KODE NEGARA	NAMA NEGARA	OPERATOR
0	id	Unggulan	any
1	id	Indonesia	any,axis,indosat,smartfren,telkomsel,three
2	vn	Vietnam	any,itelecom,mobifone,vietnamobile,viettel,vinaphone
3	my	Malaysia	any,celcom,digi,hotlink,u_mobile,xox
4	ru	Rusia	any,aiva,beeline,center2m,danycom,ezmobile,lycamobile,matrix,megafon,motiv,mts,mtt,mtt_virtual,rostelecom,sber,simsim,tele2,tinkoff,ttk,winmobile,yota
5	usa	USA	any,cellular,tmobile
6	ua	Ukraine	any,3mob,intertelecom,kyivstar,life,lycamobile,mts,utel,vodafone
7	ind	India	any
8	kaz	Kazakhstan	any,activ,altel,beeline,kcell,tele2
9	uk	United Kingdom	any,cmlink,ee,ezmobile,giffgaff,lebara,lycamobile,o2,orange,talk_telecom,teleena,three,tmobile,vectone,vodafone

`
  await conn.sendMessage(m.chat, {
text: anu,
contextInfo: {
externalAdReply: {  
title: 'O T P  I N F O',
body: namebot,
thumbnailUrl: 'https://telegra.ph/file/c0a7e37d47e6461570ec6.jpg',
sourceUrl: '',
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
}
handler.help = ['otpinfo']
handler.tags = ['tools']
handler.command = /^(otpinfo)$/i

module.exports = handler