let fetch = require('node-fetch')
let uploadImage = require('../lib/uploadImage.js')

let handler = async (m, { conn, usedPrefix, command, text }) => {
let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
let name = await conn.getName(who)
let q = m.quoted ? m.quoted : m
let mime = (q.msg || q).mimetype || ''
if (!mime) throw 'Kirim/Reply Gambar dengan caption .prompter'
m.reply('Tunggu Sebentar...')
let media = await q.download()
let url = await uploadImage(media)
let hasil = await fetch(`https://api.itsrose.life/image/stable/prompter?url=${url}&apikey=${global.rose}`)
let json = await hasil.json()
await conn.sendFile(m.chat, url, '', `${json.result.prompt}`, m)
	
}
handler.help = ['prompter']
handler.tags = ['ai']
handler.command = /^(prompter)$/i
handler.premium = true

module.exports = handler