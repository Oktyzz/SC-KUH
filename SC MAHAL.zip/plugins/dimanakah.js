let handler = async (m, { command, text }) => {
let jawab = ['Di mars', 'Di hatimu >///<', 'Di tengah laut', 'Di dada :v', 'Di neraka', 'Di surga']
let siapa = jawab[Math.floor(Math.random() * jawab.length)]
m.reply(`
*Pertanyaan:* ${command} ${text}
*Jawaban:* ${siapa}
  `.trim(), null, m.mentionedJid ? {
  mentions: m.mentionedJid
} : {})
}
handler.help = ['dimanakah <teks>']
handler.tags = ['kerang']

handler.command = /^dimanakah$/i
handler.limit = true

module.exports = handler