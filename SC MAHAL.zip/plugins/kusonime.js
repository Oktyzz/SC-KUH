// CREATE BY BANG SYAII

let fetch = require('node-fetch');

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `Mau Cari apa?`;
  let kuso = await fetch(`https://api.lolhuman.xyz/api/kusonimesearch?apikey=thuthao&query=${text}`);
  let json = await kuso.json();
  if (json.status !== 200) throw 'hasil tidak ditemukan';
  let hasil = `         *[ K U S O N I M E  B A T C H ]*
 _*Creator: Bang syaii*_
 •Judul: ${json.result.title}, ${json.result.japanese}
 •Genre: ${json.result.genre[0]}
 •Musim: ${json.result.seasons}
 •Produser: ${json.result.producers[0]}
 •Total Episode: ${json.result.total_episode}
•Score: ${json.result.score}
 •Durasi: ${json.result.duration}
•Rilis: ${json.result.released_on}
•sinopsis: ${json.result.desc}`;
  let batch = `Berikut Link Download Batch dari anime ${text} 
*•360p:*
   Google Sharer:

 ${json.result.link_dl["360P"]["Google Sharer"]}
       Google Drive:
       ${json.result.link_dl["360P"]["Google Drive"]}

__________________________________________________

*•480p:*
   Google Sharer:

 ${json.result.link_dl["480P"]["Google Sharer"]}
       Google Drive:
       ${json.result.link_dl["480P"]["Google Drive"]}`
  conn.sendFile(m.chat, json.result.thumbnail, '', hasil, m);
 await conn.reply(m.chat, batch, m);
};

handler.help = ['kusonime'].map((v) => v + ' <pencarian>');
handler.tags = ['anime'];
handler.command = /^(kusonime)$/i;

module.exports = handler;