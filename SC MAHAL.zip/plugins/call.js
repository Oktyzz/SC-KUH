let handler = async (m, {conn, text}) => {
if (!text) throw `Masukan Text!`
const a = {
scheduledCallCreationMessage: {
callType: 1, // 1 = call, 2 = vidcall
scheduledTimestampMs:  Date.now(),
title: `${text}\n\n${wm}`
}
}
conn.relayMessage(m.chat, a, {})
}
handler.command = handler.help = ['call']
handler.owner = true
module.exports = handler