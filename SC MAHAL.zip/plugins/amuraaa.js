let handler = async (m, { conn, args }) => {
  // Menghitung waktu saat ini
  let uptime = process.uptime();
  
  // Mengubah waktu menjadi format yang lebih mudah dibaca
  let hours = Math.floor(uptime / 3600);
  let minutes = Math.floor((uptime % 3600) / 60);
  let seconds = Math.floor(uptime % 60);
  
  // Mengirim pesan dengan uptime
  await conn.reply(m.chat, `Sanzy sudah aktif Kak`, m);
  conn.sendFile(m.chat, './mp3/amuraa.mp3', '', null, m, true,)
}

handler.customPrefix = /^tata|tata$/i;
handler.command = new RegExp();

module.exports = handler