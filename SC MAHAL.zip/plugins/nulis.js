const fetch = require('node-fetch');
const handler = async (m, { conn, text }) => {
  if (!text) throw 'Masukkan teksnya';
  m.reply('Tunggu sebentar...');
  const url = `https://api.lolhuman.xyz/api/nulis?apikey=Akiraa&text=${encodeURIComponent(text)}`;
  conn.sendFile(m.chat, url, '', '', m);
};
handler.command = ['nulis'];
handler.help = ['nulis'];
handler.tags = ['internet', 'maker'];
handler.limit = true;
module.exports = handler;