let fs = require('fs')
let handler = async (m, { conn }) => {
let teks = 'menu image'
let anu = `╭━━╼『 *M E N U  I M A G E* 』
┃ ▸ .darkjoke (Ⓛ)
┃ ▸ .gura (Ⓛ)
┃ ▸ .qchat (Ⓛ) (Ⓟ)
┃ ▸ .kobo (Ⓛ)
╰━━━━━━━━╼
`
  await conn.sendMessage(m.chat, {
text: anu,
contextInfo: {
externalAdReply: {  
title: 'M E N U  I M A G E',
body: namebot,
thumbnailUrl: 'https://telegra.ph/file/61465a12b843bcdf2fe9a.jpg',
sourceUrl: '',
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
}
handler.help = ['menu-image']
handler.tags = ['menulist']
handler.command = /^(menu-image)$/i

module.exports = handler