let handler = m => m

handler.all = async function (m, { isBlocked }) {
  if (isBlocked) return
  if (m.text.toLowerCase() === '.colokmemek' || m.text.toLowerCase() === '.colmek' || m.text.toLowerCase() === 'colmek') {
 (async() => {
const arr = [
  "*RUMAH SEPI*",
  "*MENGGUNAKAN KESEMPATAN ITU UNTUK NONTON BKP*",
  "*TERBAWA SUASANA DAN INGIN MEMCOBA MEMASUKKAN JARINYA KE DALAM VAGINA NYA*",
  "MULAI MEMASUKAN NYA",
  "A",
  "AH",
  "AHH",
  "AHHH",
  "A",
  "AH",
  "AHH",
  "AHHH",
  "CROTT💦💦",
  "🐷 HASIL COLMEK ANDA \n SELAMAT ANDA MENDAPATKAN \n \n DOSA 1 GUNUNG"
];

const { key } = await conn.sendMessage(m.chat, { text: '*ORTU LAGI KELUAR*' }, { quoted: m});

for (let i = 0; i < arr.length; i++) {
  await new Promise(resolve => setTimeout(resolve, 1000));
  await conn.sendMessage(m.chat, { text: arr[i], edit: key });
}})()
conn.sendFile(m.chat, './mp3/ih.mp3', '', null, m, true,)

   }
}

module.exports = handler