let fs = require('fs')
let handler = async (m, { conn }) => {
let teks = 'menu group'
let anu = `╭━━╼『 *M E N U  G R O U P* 』
┃ ▸ .accjoin
┃ ▸ .reqjoin
┃ ▸ .enable <option>
┃ ▸ .disable <option>
┃ ▸ .grouptime <open/close> <number>
┃ ▸ .hidetag <pesan>  (Ⓟ)
┃ ▸ .grup <open/close>
┃ ▸ .hidetag <pesan>  (Ⓟ)
┃ ▸ .infogrup
┃ ▸ .invite <628xxx>
┃ ▸ .kick @user
┃ ▸ .gc
┃ ▸ .group
┃ ▸ .linkgroup
┃ ▸ .grouplist
┃ ▸ .mute
┃ ▸ .poll pertanyaan|pilihan|pilihan
┃ ▸ .promote @user
┃ ▸ .setppgc
┃ ▸ .stickertag <caption|reply>
┃ ▸ .sticktag <url>
┃ ▸ .tagme
┃ ▸ .tagadmin
┃ ▸ .min
┃ ▸ .totag
┃ ▸ .unban
┃ ▸ .update <pesan>  (Ⓟ)
╰━━━━━━━━╼
`
  await conn.sendMessage(m.chat, {
text: anu,
contextInfo: {
externalAdReply: {  
title: 'M E N U  G R O U P',
body: namebot,
thumbnailUrl: 'https://telegra.ph/file/dbc69697de059f682b9ee.jpg',
sourceUrl: '',
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
}
handler.help = ['menu-group']
handler.tags = ['menulist']
handler.command = /^(menu-group)$/i

module.exports = handler