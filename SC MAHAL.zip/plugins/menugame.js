let fs = require('fs')
let handler = async (m, { conn }) => {
let teks = 'menu game'
let anu = `╭━━╼『 *M E N U  G A M E* 』
┃ ▸ .caklontong (Ⓛ)
┃ ▸ .cekpoin (Ⓛ)
┃ ▸ .chess
┃ ▸ .family100
┃ ▸ .tebakangka <angka>
┃ ▸ .kuis (Ⓛ)
┃ ▸ .siapakahaku (Ⓛ)
┃ ▸ .tebakbendera (Ⓛ)
┃ ▸ .tebakgame (Ⓛ)
┃ ▸ .hadiahspin
┃ ▸ .asahotak (Ⓛ)
┃ ▸ .jomokcek (Ⓛ)
┃ ▸ .redem <kode> (Ⓛ)
┃ ▸ .redemcode <jumlah hadiah>
┃ ▸ .wibucek (Ⓛ)
┃ ▸ .math <mode>
┃ ▸ .memanah
┃ ▸ .tembak
┃ ▸ .regmail
┃ ▸ .farmmonster
┃ ▸ .fightcentaur (Ⓛ)
┃ ▸ .fightgriffin (Ⓛ)
┃ ▸ .jackpot
┃ ▸ .hunter (Ⓛ)
┃ ▸ .pancing <type> (Ⓛ)
┃ ▸ .ojek
┃ ▸ .spin <total poin> (Ⓛ)
┃ ▸ .suitpvp @tag
┃ ▸ .suit2 @tag
┃ ▸ .susunkata (Ⓛ)
┃ ▸ .tebakanime (Ⓛ)
┃ ▸ .tebakbom
┃ ▸ .tebakgambar
┃ ▸ .tebakkata (Ⓛ)
┃ ▸ .tebakkimia (Ⓛ)
┃ ▸ .tebaklagu (Ⓛ)
┃ ▸ .tebaklirik (Ⓛ)
┃ ▸ .tekateki (Ⓛ)
┃ ▸ .tictactoe [custom room name]
┃ ▸ .ttt [custom room name]
┃ ▸ .ww
╰━━━━━━━━╼
`
  await conn.sendMessage(m.chat, {
text: anu,
contextInfo: {
externalAdReply: {  
title: 'M E N U  G A M E',
body: namebot,
thumbnailUrl: 'https://telegra.ph/file/d8d961307fb165711991d.jpg',
sourceUrl: '',
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
}
handler.help = ['menu-game']
handler.tags = ['menulist']
handler.command = /^(menu-game)$/i

module.exports = handler