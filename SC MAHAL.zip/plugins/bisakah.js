let handler = async (m, { command, text }) => {
let jawab = ['Bisa', 'Tentu tidak', 'Sudah pasti', 'Tentu saja bisa', 'Tentu tidak bisa', 'Tentu bisa']
let siapa = jawab[Math.floor(Math.random() * jawab.length)]
m.reply(`
*Pertanyaan:* ${command} ${text}
*Jawaban:* ${siapa}
  `.trim(), null, m.mentionedJid ? {
  mentions: m.mentionedJid
} : {})
}
handler.help = ['bisakah <teks>']
handler.tags = ['kerang']

handler.command = /^bisakah$/i
handler.limit = true

module.exports = handler