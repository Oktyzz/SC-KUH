let fetch = require('node-fetch');
let handler = async (m, { conn, args }) => { 
   let clockString = async (date) => {
      let month = date.getMonth() + 1;
      let day = date.getDate();
      let year = date.getFullYear();
      let hours = date.getHours() < 10 ? "0" + date.getHours() : date.getHours();
      let minutes = date.getMinutes() < 10 ? "0" + date.getMinutes() : date.getMinutes();
      let seconds = date.getSeconds() < 10 ? "0" + date.getSeconds() : date.getSeconds();
      
      return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
   }; 
   
   let date = new Date();
   let currDate = clockString(date);

   conn.reply(m.chat, `Today is ${currDate}`, m);
}

handler.help = ['calender <Creates a calendar with the given date.>'];
handler.tags = ['main']; 
handler.command = /^(calendar)$/i;

module.exports = handler;