var fetch = require("node-fetch");
let handler = async (m, { 
conn, 
text 
}) => {
  if (!text) throw 'Masukkan Text\nContoh : .lolimaker AKIRAA'
  var tio = `https://api.lolhuman.xyz/api/textprome/bloodfrosted?apikey=Akiraa&text=${text}`
  conn.sendFile(m.chat, tio, 'loliiiii.jpg', wm, m, false)
};
handler.command = handler.help = ['blood'];
handler.tags = ['maker'];
module.exports = handler;