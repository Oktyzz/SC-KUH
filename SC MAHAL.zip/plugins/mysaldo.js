let handler = async (m, { conn, text, usedPrefix, command }) => {
  let user = global.db.data.users[m.sender]
  if (!user) throw `Daftar Dulu sebelum menggunakan fitur ini ketik *.daftar*`
let saldo = user.saldo || 0
let id = user.id_saldo || 0
  
  let hasil = ` *AMURA SALDO*\n• Nama: *${conn.getName(m.sender)}*\n• ID: ${id}\n• Saldo: ${saldo}\n✅ Ketik *.deposit* untuk mengisi AmuraSaldo`
  
  await conn.sendMessage(m.chat, {
    text: hasil,
    contextInfo: {
      externalAdReply: {  
        title: "• Berikut Saldo anda",
        body: '',
        thumbnailUrl: 'https://telegra.ph/file/dacaf65239b4130ea3501.jpg',
        sourceUrl: null,
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  }, { quoted: m })
}

handler.help = ["mysaldo"]
handler.tags = ["main"]
handler.command = ["mysaldo"]
module.exports = handler