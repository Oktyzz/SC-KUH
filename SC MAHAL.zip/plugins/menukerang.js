let fs = require('fs')
let handler = async (m, { conn }) => {
let teks = 'menu kerang'
let anu = `╭━━╼『 *M E N U  K E R A N G* 』
┃ ▸ .apakah <teks> (Ⓛ)
┃ ▸ .benarkah <teks> (Ⓛ)
┃ ▸ .bisakah <teks> (Ⓛ)
┃ ▸ .dimanakah <teks> (Ⓛ)
┃ ▸ .gaycek
┃ ▸ .pintarcek
┃ ▸ .cantikcek
┃ ▸ .gantengcek
┃ ▸ .gabutcek
┃ ▸ .gilacek
┃ ▸ .lesbicek
┃ ▸ .stresscek
┃ ▸ .bucincek
┃ ▸ .jonescek
┃ ▸ .sadboycek
┃ ▸ .howgay siapa? (Ⓛ)
┃ ▸ .howpintar siapa? (Ⓛ)
┃ ▸ .howcantik siapa? (Ⓛ)
┃ ▸ .howganteng siapa? (Ⓛ)
┃ ▸ .howgabut siapa? (Ⓛ)
┃ ▸ .howgila siapa? (Ⓛ)
┃ ▸ .howlesbi siapa? (Ⓛ)
┃ ▸ .howstress siapa? (Ⓛ)
┃ ▸ .howbucin siapa? (Ⓛ)
┃ ▸ .howjones siapa? (Ⓛ)
┃ ▸ .howsadboy siapa? (Ⓛ)
┃ ▸ .howmesum siapa? (Ⓛ)
┃ ▸ .howbodoh siapa? (Ⓛ)
┃ ▸ .kapan <text>? (Ⓛ)
┃ ▸ .kapankah <text>? (Ⓛ)
┃ ▸ .siapa <teks> (Ⓛ)
┃ ▸ .siapakah <teks> (Ⓛ)
╰━━━━━━━━╼
`
  await conn.sendMessage(m.chat, {
text: anu,
contextInfo: {
externalAdReply: {  
title: 'M E N U  K E R A N G',
body: namebot,
thumbnailUrl: 'https://telegra.ph/file/4f58a17bb0b09309e2255.jpg',
sourceUrl: '',
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
}
handler.help = ['menu-kerang']
handler.tags = ['menulist']
handler.command = /^(menu-kerang)$/i

module.exports = handler