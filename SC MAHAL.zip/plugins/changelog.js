let handler = async (m, { conn, command, usedPrefix, text }) => {
  global.db.data.changelong = global.db.data.changelong || []
  let i = 0
  if (global.db.data.changelong.length == 0) return conn.reply(m.chat, 'Kamu belum punya changelog!', m)
  let txt = '🗒️CHANGELOG🗒️\n______________________\n'
  for (let ct in global.db.data.changelong) {
     i += 1
    txt += '\n' + '•' + global.db.data.changelong[ct].date + '\n\n' + '[' + i + ']. ' + global.db.data.changelong[ct].take + ' ' + global.db.data.changelong[ct].title + '\n' +
'\n_________________________________\n' 
  }
  txt += `\nChangelog Amura bot`
  if (text.length == 0) return conn.sendMessage(m.chat, {
text: txt,
contextInfo: {
externalAdReply: {  
title: 'C H A N G E L O G',
body: 'menampilkan Hari dimana fitur itu di buat',
thumbnailUrl: 'https://telegra.ph/file/035aa91905d6f331a672b.jpg',
sourceUrl: '',
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
  let catatan = global.db.data.changelong
  let split = text.split('|')
  if (catatan.length == 0) return conn.reply(m.chat, 'Kamu belum memiliki catatan!', m)
  let n = Number(split[0]) - 1

  let isi = global.db.data.changelong[n] != undefined ? global.db.data.changelong[n].isi : 'Catatan tidak ditemukan!'
  conn.reply(m.chat, `${isi}`, m, false, {
    contextInfo: {
      mentionedJid: conn.parseMention(text)
    }
  })
}

handler.help = ['logs']
handler.tags = ['main']
handler.command = /^logs$/i

module.exports = handler