let handler = async(m, { conn, text }) => {
    if (!text) throw 'Silahkan masukkan laporan'
    if (text.length > 300) throw 'Maaf Teks Terlalu Panjang, Maksimal 300 Teks!'
    const laporan = `*「 REPORT BOT 」*\nNomor : wa.me/${m.sender.split`@`[0]}\nPesan : ${text}`
    let jid = nomorown + '@s.whatsapp.net'
    m.reply(laporan, jid)
    m.reply('✅ Sukses Mengirim Laporan\n•Isi Laporan: ' + text)
}
handler.help = ['bug', 'report'].map(v => v + ' <laporan>')
handler.tags = ['info']
handler.command = /^(bug|report)$/i

module.exports = handler