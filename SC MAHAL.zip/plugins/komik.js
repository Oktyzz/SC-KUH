const fetch = require('node-fetch');

const handler = async (m, { conn, args, text }) => {
  if (!text) throw 'Masukkan Teks untuk Pencarian\nContoh: .komik Oshi no ko\n\nTambahkan parameter detail <URL> untuk melihat detail komik';
  
  if (args[0] && args[0].includes('reading')) {
    if (!args[1]) throw 'Mana url nya?\nJika belum ada, silakan ambil dari .komik detail';
    
    let res = await fetch(`https://api.nomisec07.site/api/komikcast?url=${args[1]}`);
    let p = await res.json();
    
    conn.sendFile(m.chat, p.data[0], '', '*[ K O M I K   R E A D I N G ]*\n Hasil Akan Dikirim ke Chat Pribadi Anda\n\n ```Selamat Membaca Kak><```', m);
    
    for (let imgs of p.data) {
      let ban = m.mentionedJid[0] || m.sender || conn.parseMention(args[0]) || (args[0].replace(/[@.+-]/g, '').replace(' ', '') + '@s.whatsapp.net') || '';
      conn.sendFile(ban, imgs, '', null);
    }
  } else {
    if (args[0] && args[0].includes('detail')) {
      if (!args[1]) throw 'Mana url nya?\nJika belum ada, silakan ambil dari .komik Pencarian';
      
      let url = args[1];
      let p = await fetch(`https://api.nomisec07.site/api/komikcast-chapter?url=${url}`);
      let a = await p.json();
      
      let chapter = a.data.chapters.map((v) => `*• Title:* ${v.title}\n*• Release:* ${v.release}\n*• Url:* ${v.url}`).join('\n\n_____________________________________________\n\n');
      
      let hasil = `*[ K O M I K C A S T   D E T A I L ]*   
*• TITLE:* ${a.data.title}
*• AUTHOR:* ${a.data.author}
*• STATUS:* ${a.data.status}
*• CHAPTER:* ${a.data.chapter}
*• SCORE:* ${a.data.score}
*• GENRE:* ${a.data.genre}
*• UPDATED:* ${a.data.updated} ______________________________________________________
*[ L I S T   C H A P T E R ]*
______________________________________________________

${chapter}
_____________________________________________________________`;

      conn.sendFile(m.chat, a.data.thumbnail, 'pp.jpg', hasil, m);
    } else {
      try {
        let res = await fetch(`https://api.nomisec07.site/api/komikcast-search?query=${text}`);
        let json = await res.json();
        let hasil = json.data.map((v) => `*Title:* ${v.title}\n*Type:* ${v.type}\n*Awal:* ${v.chapter}\n*Link:* ${v.url}\n*score:* ${v.score}`).join('\n_____________________________\n');
        conn.reply(m.chat, `*[ K O M I K C A S T  S E A R C H ]*\n\n${hasil}`, m);
      } catch (err) {
        conn.reply(m.chat, 'Gagal Mengambil Data Komik', m);
      }
    }
  }
};

handler.help = ['komik'];
handler.tags = ['anime'];
handler.command = /^(komik)$/i;
handler.limit = true;

module.exports = handler