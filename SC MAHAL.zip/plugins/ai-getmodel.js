const fetch = require("node-fetch");

let handler = async (m, { conn, args }) => {
  text = args.join(' ').split('|');

  if (!args[0]) {
    throw 'Masukkan nama server\nContoh : .getmodel apa\nList server:\n-frieren\n-rose\n-lisa\n-jisoo';
  }

  var tio = await fetch(`https://api.itsrose.life/image/diffusion/get_all_models?server_name=${text[0]}&apikey=${global.rose}`);
  let p = await tio.json();

  if (p.status !== true) {
    throw 'Server tidak ditemukan';
  }

  conn.reply(m.chat, p.response, m);
};

handler.command = handler.help = ['getmodel'];
handler.tags = ['ai'];
handler.premium = true;

module.exports = handler;