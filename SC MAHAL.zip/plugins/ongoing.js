let fetch = require ('node-fetch')
let handler = async(m, { conn }) => {
  let res = await fetch(`https://xzn.wtf/api/oploverz/ongoing?apikey=viva`)
  let json = await res.json()
let thumb = 'https://telegra.ph/file/9976fb5e98ca18a78e7a1.png'
  res = json.map((v) => `*Title:* ${v.title}\n*status:* ${v.status}\n*type:* ${v.score}\n*Thumbnail:* ${v.poster}\n*Link:* ${v.link}`).join`\n\n°°°°°°°°°°°°°°°°°°°°°°°°°°°°°\n\n`
  conn.relayMessage(m.chat, {
  extendedTextMessage:{
                text: res, 
                contextInfo: {
                     externalAdReply: {
                        title: 'A N I M E   U P D A T E',
                        mediaType: 1,
                        previewType: 1,
                        renderLargerThumbnail: true,
                        thumbnailUrl: thumb,
                        sourceUrl: ''
                    }
                }, mentions: [m.sender]
}}, {})
}
handler.help = ['ongoing']
handler.tags = ['anime']
handler.command = /^(ongoing)$/i
handler.limit = true
module.exports = handler