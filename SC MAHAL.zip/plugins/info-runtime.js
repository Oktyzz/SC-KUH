let handler = async (m, { conn, args }) => {
  // Menghitung waktu saat ini
  let uptime = process.uptime();
  
  // Mengubah waktu menjadi format yang lebih mudah dibaca
  let hours = Math.floor(uptime / 3600);
  let minutes = Math.floor((uptime % 3600) / 60);
  let seconds = Math.floor(uptime % 60);
  
  // Mengirim pesan dengan uptime
  await conn.reply(m.chat, `Bot telah online selama ${hours} jam, ${minutes} menit, dan ${seconds} detik`, m);
}

handler.help = ['uptime']
handler.tags = ['info']
handler.command = /^uptime$/i
module.exports = handler