let fs = require('fs')
let handler = async (m, { conn }) => {
let anu =`https://api.lolhuman.xyz/api/quotemaker2?apikey=thuthao&text=${pickRandom(global.tahun)}&author=${conn.getName(m.sender)} 

`
conn.sendFile(m.chat, anu, '', wm, m)
conn.sendFile(m.chat, './mp3/tahun.mp3', '', null, m, true, { type: "audioMessage", ptt: true, filelength: 999838483884 })
}
handler.help = ['newyears']
handler.tags = ['quotes']
handler.command = /^(newyears)$/i
module.exports = handler

function pickRandom(list) {
    return list[Math.floor(list.length * Math.random())]
}

global.tahun = [
    "Tahun Baru seperti bab dalam sebuah buku. Teruslah menulis setiap bab buku sehingga menjadi best seller. Selamat Tahun Baru 2024!",
    "Selamat Tahun Baru 2024! Semoga Anda mendapatkan tahun yang luar biasa.",
    "Mari ukir cerita dan sejarah baru di tahun 2024, tentunya dengan tujuan dan semangat baru!",
    "Fajar baru, hari baru. Semoga kita mendapat banyak cinta dan tawa di tahun ini!",
    "Tak hanya harapan, semoga 2024 menjadi tahun yang bisa lebih banyak memberikan kebaikan.",
    "Biarkan tahun baru ini membawa aspirasi, persahabatan, dan cinta baru. Mari fokus pada hal-hal yang bisa kita lakukan!",
    "Biarkan tahun baru ini membawa aspirasi, persahabatan, dan cinta baru. Mari fokus pada hal-hal yang bisa kita lakukan!",
    "Jalan panjang dan berliku telah dilewati pada 2023. Semoga di tahun 2024 ini kita selalu dikuatkan.",
    "Selamat Tahun Baru 2024 untuk orang-orang tersayang. Semoga hari-hari kalian senantiasa mudah dan menyenangkan!",
    "Terima kasih 2023! Semoga kita semua bisa meraih mimpi dan cita-cita baru di tahun 2024. Selamat Tahun Baru!",
   "Mari rayakan pencapaian kemarin dan masa depan yang cerah untuk esok. Selamat tahun baru 2024!.",
   "Bulatkan tekad dan jadikan hidupmu lebih berarti di tahun ini. Selamat Tahun Baru 2024!",
    "Saatnya melupakan masa lalu untuk merayakan awal yang baru. Selamat Tahun Baru 2024!",
    "Semoga tahun baru dapat mengisi hati dan jiwamu dengan harapan, impian, dan aspirasi baru. Selamat tahun baru 2024!",
    "Lembaran baru telah dibuka. Tahun yang jauh lebih cerah dari perayaan ini. Aku mengharapkan segala yang terbaik. Mari sambut kehidupan yang penuh berkat. Selamat tahun baru!",
    "Lembaran baru telah dibuka. Tahun yang jauh lebih cerah dari perayaan ini. Aku mengharapkan segala yang terbaik. Mari sambut kehidupan yang penuh berkat. Selamat tahun baru!"
]