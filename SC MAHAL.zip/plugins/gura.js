let {sticker5} = require ('../lib/sticker.js')
const axios = require('axios');
var handler = async (m, { conn, args, usedPrefix, command }) => {
    m.reply(wait);
    let url = 'https://api.lolhuman.xyz/api/sticker/gawrgura?apikey=Akiraa';
let stiker = await sticker5(url, false, global.packname, global.author)
    if (stiker) return conn.sendFile(m.chat, stiker, 'Quotly.webp', '', m)
}
handler.help = ['gura']
handler.tags = ['image']
handler.command = /^(gura)$/i
handler.limit = true;
module.exports = handler;