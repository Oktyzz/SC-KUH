let fetch = require('node-fetch')
let handler = async (m, { text, usedPrefix, command }) => {
     if (!text) throw `Masukan nama nabi\nExample: ${usedPrefix + command} adam`
     let url = await fetch(`https://api.lolhuman.xyz/api/kisahnabi/${text}?apikey=Akiraa`)
     let kisah = await url.json()
     let hasil = ` Nabi : ${kisah.result.name}\nTanggal Lahir : ${kisah.result.thn_kelahiran}\nTempat Lahir : ${kisah.result.place}\nUsia : ${kisah.result.age}\nKisah : ${kisah.result.story}`
     conn.reply(m.chat, hasil, m)
     }
handler.help = ['kisahnabi <name>']
handler.tags = ['islam']
handler.command = /^kisahnabi$/i
handler.register = false
handler.limit = true

module.exports = handler