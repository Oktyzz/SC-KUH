const axios = require("axios");

let handler = async (m, { conn, text }) => {
  if (!text) throw `Halo Kak`;
  try {
    let simi = await getMessage(m.text, "id");
    conn.reply(m.chat, simi, m);
  } catch (e) {
    throw "Maaf, aku tidak mengerti";
  }
};

handler.command = /^(simi|chatbot)$/i;
module.exports = handler;

async function getMessage(yourMessage, langCode) {
  const res = await axios.post(
    "https://api.simsimi.vn/v2/simtalk",
    new URLSearchParams({
      text: yourMessage,
      lc: langCode,
    })
  );

  if (res.status !== 200) throw new Error(res.data.success);

  return res.data.message;
}