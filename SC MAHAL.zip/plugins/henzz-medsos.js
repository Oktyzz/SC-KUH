let fs = require('fs')
let handler = async (m, { conn }) => {
let teks = 'youtube owner'
let anu = `*JANGAN LUPA SUBCRIBE DAN FOLLOW YA*
YT : https://youtube.com/@salsaBoTz-MD
TELEGRAM : t.me/SALShop1
WA : wa.me/84528059414
`
  await conn.sendMessage(m.chat, {
text: anu,
contextInfo: {
externalAdReply: {  
title: 'C H A N N E L   YT   D A N   M E D S O S   O W N E R',
body: namebot,
thumbnailUrl: 'https://telegra.ph/file/e83a81409ce7e98d9713e.jpg',
sourceUrl: '',
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
}
handler.help = ['yt','youtube','medsos']
handler.tags = ['main']
handler.command = /^(yt|youtube|medsos)$/i

module.exports = handler