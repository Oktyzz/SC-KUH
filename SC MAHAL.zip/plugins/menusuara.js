let fs = require('fs')
let handler = async (m, { conn }) => {
let teks = 'menu suara'
let anu = `╭━━╼『 *M E NU  S U A R A* 』
┃ ▸ .tomp3
┃ ▸ .tovn
╰━━━━━━━━╼
`
  await conn.sendMessage(m.chat, {
text: anu,
contextInfo: {
externalAdReply: {  
title: 'M E N U  S U A R A',
body: namebot,
thumbnailUrl: 'https://telegra.ph/file/d1365810b4e009833896e.jpg',
sourceUrl: '',
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
}
handler.help = ['menu-suara']
handler.tags = ['menulist']
handler.command = /^(menu-suara)$/i

module.exports = handler