let handler  = async (m, { conn }) => {
  conn.reply(m.chat,`“${pickRandom(global.jomok)}”`, m)
}
handler.help = ['jomokcek']
handler.tags = ['game']
handler.command = /^(jomokcek)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.limit = true

module.exports = handler 

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}

global.jomok = [
'Jomok Level : 4%\n\nMasih Aman Lah Yaa!',
'Jomok Level : 7%\n\nMasih Aman',
'Jomok Level : 12%\n\nAman Kok',
'Jomok Level : 22%\n\nHampir Aman',
'Jomok Level : 27%\n\nJomok dikit',
'Jomok Level : 35%\n\nJomok ¼',
'Jomok Level : 41%\n\nDah lewat dri Aman',
'Jomok Level : 48%\n\nSetengah Jomok',
'Jomok Level : 56%\n\nLu Jomok juga',
'Jomok Level : 64%\n\nLumayan Jomok',
'Jomok Level : 71%\n\nPasti Lu Punya Seribu Waifu',
'Jomok Level : 1%\n\n99% LU GAK Jomok!',
'Jomok Level : 77%\n\nGak akan Salah Lagi dah Jomoknya lu',
'Jomok Level : 83%\n\nDijamin Sepuhnya Jomok',
'Jomok Level : 89%\n\nFix Jomok Elite!',
'Jomok Level : 94%\n\nUdah Elite Sih Ini😂',
'Jomok Level : 100%\n\nHITAM BAU PANDAN SAMPE SINI CUY!!!',
'Jomok Level : 100%\n\nHITAM BAU PANDAN SAMPE SINI CUY!!!',
'Jomok Level : 100%\n\nHITAM BAU PANDAN SAMPE SINI CUY!!!',
'Jomok Level : 100%\n\nHITAM BAU PANDAN SAMPE SINI CUY!!!',
]