let handler = m => m

handler.before = async function (m) {
  let chat = global.db.data.chats[m.chat];
  if (chat.antiBot) {
if (m.formMe) return 
    if (m.isBaileys == true) {
         conn.reply(m.chat, "*[ ANOTHER BOT DETECTED ]*", m);
        await conn.groupParticipantsUpdate(m.chat, [m.sender], "remove");
      }
      return 0;
    }
  }
module.exports = handler