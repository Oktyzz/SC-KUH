const schedule = require('node-schedule');

let executed = false;
let messageCount = 0; // Menambahkan variabel untuk menghitung jumlah pesan yang dikirimkan

module.exports = (conn) => {
  schedule.scheduleJob('0 5 * * *', async function () {
    executed = false;
    messageCount = 0; // Mereset jumlah pesan yang dikirimkan setiap harinya
  });

  conn.on('chat-update', async (m) => {
    if (executed) return;

    const currentTime = new Date();
    const targetTime = new Date();
    targetTime.setHours(19, 52, 0);

    if (currentTime >= targetTime && messageCount === 0) {
      conn.reply(m.chat, '*[Akiraa Notif]* Sudah pukul *21.00* tuan waktunya untuk tidur😪😴\n Grup akan di buka pukul *05.00*', null);
      await conn.groupSettingUpdate(m.chat, 'announcement');
      executed = true;
      messageCount++;
    }

    if (currentTime.getHours() >= 20 && !executed && messageCount === 0) {
      conn.reply(m.chat, '*[Akiraa Notif]* Sudah pukul *05.00* tuan waktunya untuk menutup grup 🌙🌟', null);
      await conn.groupSettingUpdate(m.chat, 'not_announcement');
      executed = true;
      messageCount++;
    }
  });
};