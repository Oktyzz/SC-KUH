let handler = async (m, { conn, args, usedPrefix, command }) => {
let response = args.join(' ').split(' ')
if (! response[0]) {
let p = `format salah!!
contoh:
${usedPrefix + command} 6283842839555 terima
${usedPrefix + command} 6283842839555 tolak`
m.reply(p)
}
conn.groupRequestParticipantsUpdate(m.chat,[`${response[0]}@s.whatsapp.net`], `${response[1]}`)
m.reply('Suksess✅')
}
handler.help = ['accjoin','reqjoin']
handler.tags = ['group']
handler.command = /^(accjoin|reqjoin)$/i
handler.admin = true
handler.botAdmin = true
handler.group = true
module.exports = handler