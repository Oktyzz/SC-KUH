const fetch = require("node-fetch");

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `Masukkan Text\n\nContoh:\n${usedPrefix + command} Akane kurokawa`;;
  const apis = await fetch(`https://xzn.wtf/api/ttsearch?search=${text}&apikey=seika`);	
  const json = await apis.json();
  await conn.sendFile(m.chat, json.play, 'tiktok.mp4', `
*•Deskripsi*: ${json.title}
*•Region*: ${json.region}
*•Durasi*: ${json.duration} detik
____________________________________`, m);
  await conn.sendFile(m.chat, json.music, 'error.mp3', null, m, true);
};

handler.help = ['tiktoksearch'];
handler.command = /^(tiktoksearch|ttsearch|tiktoks)$/i;
handler.tags = ['downloader'];
handler.limit = true;
handler.group = false;
handler.premium = false;
handler.owner = false;
handler.admin = false;
handler.botAdmin = false;
handler.fail = null;
handler.private = false;

module.exports = handler;