let fs = require('fs')
let handler = async (m, { conn }) => {
let teks = 'menu premium'
let anu = `╭━━╼『 *M E N U  P R E M I U M* 』
┃ ▸ .bokep  (Ⓟ)
┃ ▸ .doujinlatest  (Ⓟ)
┃ ▸ .doujinsearch <kata kunci>  (Ⓟ)
┃ ▸ .hentai <kata kunci>  (Ⓟ)
┃ ▸ .join <chat.whatsapp.com>  (Ⓟ)
┃ ▸ .premlimit @user <amount>  (Ⓟ)
┃ ▸ .premxp @user <amount>  (Ⓟ)
╰━━━━━━━━╼
`
  await conn.sendMessage(m.chat, {
text: anu,
contextInfo: {
externalAdReply: {  
title: 'M E N U  P R E M I U M',
body: namebot,
thumbnailUrl: 'https://telegra.ph/file/38403d9b568b94a6e23df.jpg',
sourceUrl: '',
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
}
handler.help = ['menu-premium']
handler.tags = ['menulist']
handler.command = /^(menu-premium)$/i

module.exports = handler