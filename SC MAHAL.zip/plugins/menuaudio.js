let fs = require('fs')
let handler = async (m, { conn }) => {
let teks = 'menu audio'
let anu = `╭━━╼『 *M E N U. A U D l O* 』
┃ ▸ .cut <text>
┃ ▸ .vnkobo
┃ ▸ .bass <vn> (Ⓛ)
┃ ▸ .blown <vn> (Ⓛ)
┃ ▸ .deep <vn> (Ⓛ)
┃ ▸ .earrape <vn> (Ⓛ)
┃ ▸ .fast <vn> (Ⓛ)
┃ ▸ .fat <vn> (Ⓛ)
┃ ▸ .nightcore <vn> (Ⓛ)
┃ ▸ .reverse <vn> (Ⓛ)
┃ ▸ .robot <vn> (Ⓛ)
┃ ▸ .slow <vn> (Ⓛ)
┃ ▸ .smooth <vn> (Ⓛ)
┃ ▸ .tupai <vn> (Ⓛ)
┃ ▸ .vibra <vn> (Ⓛ)
╰━━━━━━━━╼
`
  await conn.sendMessage(m.chat, {
text: anu,
contextInfo: {
externalAdReply: {  
title: 'M E N U  A U D I O',
body: namebot,
thumbnailUrl: 'https://telegra.ph/file/e511f68086987fdc80d0f.jpg',
sourceUrl: '',
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
}
handler.help = ['menu-audio']
handler.tags = ['menulist']
handler.command = /^(menu-audio)$/i

module.exports = handler