/*EDIT OWNER DISINI
*/
global.owner = [
  ['12679068479'],
  ['6287841753177'],
  ['6285608953677', 'OKTZ ', 'oktzoffc@gmail.com', true]
] // Put your number here
global.mods = ['12679068479'] // Moderator
global.prems = ['12679068479'] // Premium
// YANG ATAS ITU UBAH JADI NOMOR LU
// & YG BAWAH INI, NOMOR,NAMA,EMAIL LU
global.fsizedoc = '45000000000' // default 10TB
global.fpagedoc = '19'
global.numberbot = '6282249503984'
global.namedoc = 'ᴏᴋᴛᴢ - ᴍᴅ'
global.nameowner = 'ᴏᴋᴛᴢ'
global.mail = 'tataverifakun@gmail.com'
global.nomorown = '12679068479' 
global.dana = '6287841753177'
global.pulsa = '6287841753177'
global.gopay = '6287841753177'
global.namebot = 'ᴏᴋᴛᴢ - ᴍᴅ'
global.sgc = 'https://chat.whatsapp.com/EtKBlyudN8k2Asbk6AqehA'
global.sourceUrl = "https://instagram.com/"
global.sig = 'https://instagram.com/'
global.swa = 'wa.me/12679068479'
global.thumb = 'https://telegra.ph/file/191255466221149ca48d0.jpg'
global.version = '6.5.0'
global.wm = 'ᴏᴋᴛᴢ - ᴍᴅ'
global.watermark = wm
global.wm2 = 'ᴏᴋᴛᴢ '
global.wm3 = namebot
global.danied = '*Command tidak dapat di akses!!!*' 
global.wm4 = namebot
global.fla = 'https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=water-logo&script=water-logo&fontsize=90&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextColor=%23000&shadowGlowColor=%23000&backgroundColor=%23000&text='
global.wait = '*🍿 SEDANG LOADING MOHON TUNGGU. . .*'
global.eror = 'Server Error'
global.benar = 'Benar\n'
global.salah = 'Salah\n'
global.web = global.sourceUrl

// GANTI WM DISINI

global.stiker_wait = 'Sedang Di Proses...'
global.packname = 'By 𝙗𝙤𝙩𝙯 𝗦𝗔𝗟𝗦𝗵𝗼𝗽|𝙤𝙬𝙣 𝟬𝟴𝟭𝟯\nS T I C K E R  M A K E R\n\nnomor bot: wa.me/6282249503984'
global.author = ''
global.APIs = {
  lolhuman: 'https://api.lolhuman.xyz',
  rose: 'https://api.itsrose.life',
  skizo: 'https://xzn.wtf/',
  sazumiviki: 'https://api.sazumiviki.me'
};

global.APIKeys = {
  'https://api.sazumiviki.me': 'sazumiviki',
  'https://xzn.wtf/': 'sazumiviki',
  'https://api.itsrose.life': 'YOUR_ROSE_KEY',
  'https://api.lolhuman.xyz': 'momo',
};
global.multiplier = 45
global.rpg = {
  emoticon(string) {
    string = string.toLowerCase()
    let emot = {
      exp: '✉️',
      money: '💵',
      potion: '🥤',
      diamond: '💎',
      common: '📦',
      uncommon: '🎁',
      mythic: '🗳️',
      legendary: '🗃️',
      pet: '🎁',
      sampah: '🗑',
      armor: '🥼',
      sword: '⚔️',
      kayu: '🪵',
      batu: '🪨',
      string: '🕸️',
      kuda: '🐎',
      kucing: '🐈' ,
      anjing: '🐕',
      petFood: '🍖',
      gold: '👑',
      emerald: '💚'
    }
    let results = Object.keys(emot).map(v => [v, new RegExp(v, 'gi')]).filter(v => v[1].test(string))
    if (!results.length) return ''
    else return emot[results[0][0]]
  }
}

/*Yang Ini Jangan Di Ubah Yah Kak*/
let fs = require('fs')
let chalk = require('chalk')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  delete require.cache[file]
  require(file)
})