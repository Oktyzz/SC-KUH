 [![-------------------------------------------- ---------](https://raw.githubusercontent.com/andreasbm/readme/master/assets/lines/colored.png)](#table-of-contents)



### Updates / Updates
- Has used multiple auth sessions
- Fixed QR code in the terminal
-Fixed logs
- Fix waiting for messages
- Fixed delay Messages
- Can be deployed on replit and render
- - For the rest, add your own features because this is just a base.

- My free apikey (betabotz) is only 5 limits per day if you want to have more limits please register first, then chat with me to increase the limit [lann](http://wa.me/6287764694844?text=.register )
- Free apikey botcahx only 100 limit per day if you want to have more limit please register first, then chat my bot [botcahx](http://wa.me/62813958616959?text=.claimtrial )

+ Register Key [`botcahx`](https://api.botcahx.live)
+ And Register Here [`lann`](https://api.betabotz.org)

- After getting the key paste in config.js in the global.btc and global.lann lines

## LANGUAGES

[`EN /`](https://github.com/ERLANRAHMAT/BETABOTZ-MD2/blob/v1/README.md)

- Change the language using the direct link above.


##Support

<a href="https://sociabuzz.com/tioclkp02" target="_blank"><img src="https://img.shields.io/badge/Buy_Me_A_Coffee-FFDD00?style=for-the-badge&logo= buy-me-a-coffee&logoColor=black" height="32px" alt="Sociabuzz"></a>

### `Replied`

[![Run on Repl.it](https://repl.it/badge/github/ERLANRAHMAT/BETABOTZ-MD2)](https://repl.it/github/ERLANRAHMAT/BETABOTZ-MD2)

  

### `Render`

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://dashboard.render.com/blueprint/new?repo=https%3A% 2F%2Fgithub.com%2FBOTCAHX%2FRTXZY-MD)



## Base Ori
Original base [`Link`](https://github.com/HelgaIlham/ZukaBet)

##Original script
Script By [`Botcahx`](https://github.com/BOTCAHX/RTXZY-MD)

## Join the Discussion Group

[![ALL BOT WHATSAPP](https://img.shields.io/badge/WhatsApp%20Group-25D366?style=for-the-badge&logo=whatsapp&logoColor=red)](https://chat.whatsapp.com/ Ln2vHjRrRayAbzalRMB56r)



## Run On My Hero

Simple WhatsApp Bot

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/ERLANRAHMAT/BETABOTZ-MD2)

```bash
Login with your github
Click Launch Dev Environment
Choose your repository
```
## FOR WINDOWS/VPS/RDP USERS

* Download & Install Git [`Click Here`](https://git-scm.com/downloads)
* Download & Install NodeJS [`Click Here`](https://nodejs.org/en/download)
* Download & Install FFmpeg [`Click Here`](https://ffmpeg.org/download.html) (**Don't Forget to Add FFmpeg to PATH environment variable**)
* Download & Install ImageMagick [`Click Here`](https://imagemagick.org/script/download.php)

```bash
git clone https://github.com/ERLANRAHMAT/BETABOTZ-MD2
cd BETABOTZ-MD2
npm i
npm start
```
# Heroku Buildpack
### Install Buildpack
```bash
* heroku/nodejs
* https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest.git
* https://github.com/clhuang/heroku-buildpack-webp-binaries.git
```


### `--prefix <prefix>`

* `prefixes` separated by each character
Set prefix

### `--server`

Used for [heroku](https://heroku.com/) or scan through the website

### `--db <json-server-url>`

use external db instead of local db, **recommended** use mongodb

server example with mongodb db:node . --db "mongodb+srv://botwa:Jxrt6KiUNOOccDuo@cluster0.dytrn2e.mongodb.net/?retryWrites=true&w=majority" --autocleartmp --restrict

server example with repl `https://json-server.tioclkp02.repl.co/`

code: `https://repl.it/@tioclkp02/json-server`

`nodes . --db 'https://json-server.tioclkp02.repl.co/'`

the server must have specifications like this

#### GET

```http
GET /
Accept: application/json
```

#### POST

```http
POST /
Content-Type: application/json

{
 data: {}
}
```

### `--big-qr`

If qr small unicode not support

### `--img`

Activate image checker via terminal

### `--test`

**Development** Test Mode

### `--trace`

```js
conn.logger.level = 'trace'
```

### `--debug`

```js
conn.logger.level = 'debug'
```
#### Thanks To
- Allah SWT

- Parent



- Everyone was involved in making this script





### All Contributors

[`Visit`](https://github.com/BOTCAHX/RTXZY-MD/graphs/contributors)


 
##### All Contributors
<a href="https://github.com/BOTCAHX"><img src="https://github.com/BOTCAHX.png?size=100" width="100" height="100"></ a> | [![Erlan](https://github.com/ERLANRAHMAT.png?size=100)](https://github.com/ERLANRAHMAT)
---|---
[Tio](https://github.com/BOTCAHX) | [Erlan](https://github/ERLANRAHMAT)
Recode | Contributors |

##### Special Thanks To
<!--[![Nurutomo](https://github.com/Nurutomo.png?size=100)](https://github.com/Nurutomo)
[![BochilGaming](https://github.com/BochilGaming.png?size=100)](https://github.com/BochilGaming)
[![adiwajshing/Baileys](https://github.com/adiwajshing.png?size=100)](https://github.com/adiwajshing)-->
<a href="https://github.com/BochilGaming"><img src="https://github.com/BochilGaming.png?size=100" width="100" height="100"></ a> | [![NURUTOMO](https://github.com/Nurutomo.png?size=100)](https://github.com/Nurutomo)
---|---
[Bochilgaming](https://github.com/BochilGaming) | [Nurutomo](https://github.com/Nurutomo)
elder | elder |
